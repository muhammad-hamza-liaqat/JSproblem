//Q2: Create a function that will receive two arrays of numbers as arguments and return an array composed of all the numbers that are either in the first array or second array but not in both

function setDifferent(arr1, arr2) {
  // Create two sets..
  const setOne = new Set(arrayOne);
  const setTwo = new Set(arrayTwo);
  // identify the unique elements which are not in set 1 or set 2 of array
  const result = new Set([...setOne].filter(number => !setTwo.has(number)).concat([...setTwo].filter(number => !setOne.has(number))));
  // Convert the result set back to an array
  return Array.from(result);
}

const arrayOne = [1, 2, 3, 4, 5];
const arrayTwo = [3, 4, 5,6,7];
const result = setDifferent(arrayOne, arrayTwo);
console.log("set-1", arrayOne);
console.log("set-1", arrayTwo);
console.log("identify the unique elements which are not in set 1 or set 2 of array");
console.log("final set=>",result); 