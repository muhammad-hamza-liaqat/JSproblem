// sort the unsorted stack class in descending order
// desc means higher to lower.

class Stack {
    constructor() {
        this.items = [];
    }

    push(element) { 
        this.items.push(element);
    }

    pop() { 
        if (this.isEmpty()) {
            return "The stack is empty";
        } else {
            return this.items.pop();
        }
    }

    isEmpty() {
        return this.items.length === 0;
    }
    //  the desc code logic here, the main func
    // higher to lower order....
    sortInDesc(){
        this.items.sort((a,b)=> b - a);
    }
}
const unSorted = new Stack();
unSorted.push(5);
unSorted.push(9);
unSorted.push(19);
unSorted.push(15);
unSorted.push(1);
unSorted.push(7);
unSorted.push(6);

// console.log("the unstoredStack=>", unSorted);
console.log("the unstoredStack=>", unSorted.items);
unSorted.sortInDesc();
console.log("sorted in desc order=>", unSorted.items);

