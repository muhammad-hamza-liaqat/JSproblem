function isPrimeAndTotal(MAX){
    const primeList = [];
    let sum = 0;
    for (let number = 2; number <= MAX; number++) {
        if (isPrimeNumber(number)) {
            primeList.push(number);
            sum = sum + number;
        }
    }
    return { primeList, sum };
}

function isPrimeNumber(number){
    if (number <= 1) return false;
    if (number <= 3) return true;
    if (number % 2 === 0 || number % 3 === 0) return false;

    for (let i = 5; i * i <= number; i += 6) {
        if (number % i === 0 || number % (i + 2) === 0) return false;
    }

    return true;
}

const { primeList, sum } = isPrimeAndTotal(100);

console.log("Prime Numbers:", primeList);
console.log("Total Sum of Prime Numbers:", sum);
