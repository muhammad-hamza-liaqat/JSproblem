// Q1: Create a function that will receive two arrays and will return an array with elements that are in the first array but not in the second
// find the elements in the first array that are not present in the second array

function elementNotInAnother(arrayOne, arrayTwo){
  return arrayOne.filter(number=> !arrayTwo.includes(number));
}


// declare the arrays

let arrayOne =[1,2,3,4,5];
let arrayTwo =[3,4,5,6,7];

// call the function and store it in a variable

let Final = elementNotInAnother(arrayOne,arrayTwo);
console.log("the arrayOne=>", arrayOne);
console.log("the arrayTwo=>", arrayTwo);
console.log("// find the elements in the first array that are not present in the second array");
console.log("finalArray=>", Final);