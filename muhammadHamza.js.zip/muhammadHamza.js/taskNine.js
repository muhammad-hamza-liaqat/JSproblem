class Stack {
  constructor() {
    this.items = [];
  }

  push(item) {
    this.items.push(item);
  }

  pop() {
    return this.items.pop();
  }

  isEmpty() {
    return this.items.length === 0;
  }
}

function mergeStacks(stack1, stack2) {
  const mergedStack = new Stack();

  // Pop elements from stack1 and push into mergedStack
  while (!stack1.isEmpty()) {
    mergedStack.push(stack1.pop());
  }

  // Pop elements from stack2 and push into mergedStack
  while (!stack2.isEmpty()) {
    mergedStack.push(stack2.pop());
  }

  return mergedStack;
}

// pushing in s1 and s2;
const s1 = new Stack();
s1.push(123);
s1.push(456);
s1.push(789);

const s2 = new Stack();
s2.push(12);
s2.push(19);
s2.push(69);
console.log("stack 1:", s1);
console.log("stack 1:", s2);
const mergedStack = mergeStacks(s1, s2);


console.log("Merged Stack=>");
while (!mergedStack.isEmpty()) {
  console.log(mergedStack.pop());
}
