// //Q5: Write a JavaScript function that fetches data from an API and cancels the request if it takes longer than a specified time
// Reference: https://www.freecodecamp.org/news/javascript-settimeout-how-to-set-a-timer-in-javascript-or-sleep-for-n-seconds/

function dataFromAPI(){                                             //will exceute this after 5 sec
    console.log("started to getting data from an API......");
};
const timeoutID = setTimeout(dataFromAPI,5000); // calling dataFromAPI() and settig it time to 5 milliseconds

setTimeout(()=>{
    clearTimeout(timeoutID);
    console.log("Failed to fetch the data from API... Error: TimeOut");
},1500); 
// it will wait for 1500 milliseconds or 1.5Sec if the timeoutID is exceuted in this time range, it will not exceute else it will exceute...(setTimeOut) 