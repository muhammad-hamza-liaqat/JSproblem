class Stack{
    constructor(){
        this.items =[];
    }
    isEmpty(){
        return this.items.length === 0;
    }
    push(element){
        this.items.push(element);
    }
    pop(){
        if (this.isEmpty()){
            return "The stack is empty";
        }else{
            return this.items.pop();
        }
    }
    // max code logic
    findMaxElement(){
        if (this.isEmpty()){
            return "the stack is empty"
        }else{
            let MAX= this.items[0]
            for(let index=1;index<=this.items.length;index++){
                if(this.items[index]>MAX){
                    MAX = this.items[index];
                }
            }
            return MAX;
        }
    }
    findMinElement(){
        if(this.isEmpty()){
            return "the stack is empty"
        } else{
            let MIN= this.items[0];
            for (let index=1;index<=this.items.length;index++){
                if (this.items[index]< MIN){
                    MIN= this.items[index];
                }
            }
            return MIN;
        }

    }

}

const stack1 = new Stack();
stack1.push(1);
stack1.push(5);
stack1.push(15);
stack1.push(20);
stack1.push(100);  
console.log("max element=>", stack1.findMaxElement());
console.log("min element=>", stack1.findMinElement());  